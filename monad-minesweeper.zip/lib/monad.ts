
import { createWalletClient, http, parseAbi } from 'viem'
import { privateKeyToAccount } from 'viem/accounts'

const CONTRACT = '0xceCBFF203C8B6044F52CE23D914A1bfD997541A4' as `0x${string}`

const abi = parseAbi([
  'function updatePlayerData(address player, uint256 scoreAmount, uint256 transactionAmount)',
  'function registerGame(address _game, string _name, string _image, string _url)'
])

function chainFromEnv() {
  const id = Number(process.env.CHAIN_ID || 10143)
  const rpc = process.env.MONAD_RPC || 'https://testnet-rpc.monad.xyz'
  return {
    id,
    name: 'Monad Testnet',
    nativeCurrency: { name:'MON', symbol:'MON', decimals: 18 },
    rpcUrls: { default: { http: [rpc] } }
  } as const
}

export async function writeUpdatePlayerData(player: `0x${string}`, scoreDelta: bigint, txDelta: bigint) {
  const pk = process.env.GAME_SIGNER_PK as `0x${string}`
  if (!pk) throw new Error('Missing GAME_SIGNER_PK')
  const account = privateKeyToAccount(pk)
  const client = createWalletClient({ account, chain: chainFromEnv(), transport: http(process.env.MONAD_RPC) })
  return await client.writeContract({
    address: CONTRACT,
    abi,
    functionName: 'updatePlayerData',
    args: [player, scoreDelta, txDelta]
  })
}

export { CONTRACT, abi }


'use client'
import React, { useEffect, useMemo, useRef, useState } from 'react'

type Difficulty = 'easy' | 'medium' | 'hard'
type StartResp = { boardId: string, seed: string, w: number, h: number, mines: number, boardHash: string }
type Move = { r: number, c: number, a: 'reveal' | 'flag' | 'unflag', t: number }

function range(n: number) { return [...Array(n).keys()] }
function key(r: number, c: number) { return r + ':' + c }

export default function GameBoard({ player }: { player: string }) {
  const [difficulty, setDifficulty] = useState<Difficulty>('easy')
  const [game, setGame] = useState<StartResp | null>(null)
  const [startedAt, setStartedAt] = useState<number>(0)
  const [duration, setDuration] = useState<number>(0)
  const [moves, setMoves] = useState<Move[]>([])
  const [state, setState] = useState<'idle' | 'playing' | 'win' | 'lose'>('idle')

  // board view states
  const [revealed, setRevealed] = useState<Set<string>>(new Set())
  const [flags, setFlags] = useState<Set<string>>(new Set())
  const [numbers, setNumbers] = useState<number[]>([]) // computed client-side from seed

  // Generate layout & numbers locally (client) from seed for UI experience
  // IMPORTANT: Server will re-simulate from seed to verify.
  const layout = useMemo(() => {
    if (!game) return [] as boolean[]
    return generateLayout(game.w, game.h, game.mines, game.seed)
  }, [game])

  useEffect(() => {
    if (!game) return
    setNumbers(computeNumbers(layout, game.w, game.h))
  }, [game, layout])

  useEffect(() => {
    if (state !== 'playing') return
    const id = setInterval(() => setDuration(Date.now() - startedAt), 100)
    return () => clearInterval(id)
  }, [state, startedAt])

  async function start() {
    const res = await fetch('/api/new-board', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ difficulty, player })
    })
    const data = await res.json() as StartResp
    setGame(data)
    setRevealed(new Set())
    setFlags(new Set())
    setMoves([])
    setDuration(0)
    setState('playing')
    setStartedAt(Date.now())
  }

  function neighbors(r: number, c: number) {
    const acc: [number, number][] = []
    for (let dr of [-1,0,1])
      for (let dc of [-1,0,1]) {
        if (dr===0 && dc===0) continue
        const nr=r+dr, nc=c+dc
        if (nr>=0 && nr<(game?.h||0) && nc>=0 && nc<(game?.w||0)) acc.push([nr,nc])
      }
    return acc
  }

  function onReveal(r: number, c: number) {
    if (!game || state!=='playing') return
    const k = key(r,c)
    if (revealed.has(k) || flags.has(k)) return

    const t = Date.now()
    setMoves(m => [...m, { r, c, a: 'reveal', t }])

    if (layout[r*game.w + c]) {
      // hit mine
      setState('lose')
      setRevealed(new Set([...revealed, k]))
      finish('lose', [...moves, { r,c,a:'reveal',t }])
      return
    }

    // flood fill
    const toOpen: string[] = []
    const stack: [number, number][] = [[r,c]]
    const newRev = new Set(revealed)
    while (stack.length) {
      const [rr, cc] = stack.pop()!
      const kk = key(rr,cc)
      if (newRev.has(kk)) continue
      newRev.add(kk)
      toOpen.push(kk)
      const val = numbers[rr*game.w + cc]
      if (val === 0) {
        for (const [nr,nc] of neighbors(rr,cc)) {
          const k2 = key(nr,nc)
          if (!newRev.has(k2) && !layout[nr*game.w + nc]) stack.push([nr,nc])
        }
      }
    }
    setRevealed(newRev)

    // win check
    const safeCells = game.w*game.h - game.mines
    if (newRev.size >= safeCells) {
      setState('win')
      finish('win', [...moves, { r,c,a:'reveal',t }])
    }
  }

  function onRightClick(e: React.MouseEvent, r: number, c: number) {
    e.preventDefault()
    if (!game || state!=='playing') return
    const k = key(r,c)
    const t = Date.now()
    if (flags.has(k)) {
      const n = new Set(flags); n.delete(k); setFlags(n)
      setMoves(m => [...m, { r, c, a: 'unflag', t }])
    } else if (!revealed.has(k)) {
      const n = new Set(flags); n.add(k); setFlags(n)
      setMoves(m => [...m, { r, c, a: 'flag', t }])
    }
  }

  async function finish(result: 'win'|'lose', mv: Move[]) {
    if (!game) return
    try {
      const r = await fetch('/api/finish', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          boardId: game.boardId,
          player,
          moves: mv,
          duration_ms: Date.now() - startedAt
        })
      })
      const j = await r.json()
      console.log('Finish:', j)
    } catch (e) {
      console.error(e)
    }
  }

  return (
    <div>
      <div className="toolbar">
        <select value={difficulty} onChange={e=>setDifficulty(e.target.value as Difficulty)}>
          <option value="easy">Easy (9x9, 10 mines)</option>
          <option value="medium">Medium (16x16, 40 mines)</option>
          <option value="hard">Hard (30x16, 99 mines)</option>
        </select>
        <button onClick={start}>{state==='playing' ? 'Restart' : 'Start'}</button>
        <div><b>Time:</b> {(duration/1000).toFixed(1)}s</div>
        <div><b>Status:</b> {state}</div>
      </div>

      {game && (
        <div className="board" style={{ gridTemplateColumns: `repeat(${game.w}, 28px)` }}>
          {range(game.h).flatMap(r => range(game.w).map(c => {
            const k = key(r,c)
            const isMine = layout[r*game.w + c]
            const isRevealed = revealed.has(k)
            const isFlag = flags.has(k)
            const n = numbers[r*game.w + c] || 0
            return (
              <div
                key={k}
                className={`cell ${isRevealed ? 'revealed' : isFlag ? 'flag' : 'hidden'}`}
                onClick={()=>onReveal(r,c)}
                onContextMenu={(e)=>onRightClick(e,r,c)}
              >
                {isRevealed ? (isMine ? '💣' : (n>0?n:'')) : (isFlag?'🚩':'')}
              </div>
            )
          }))}
        </div>
      )}
    </div>
  )
}

// ======= UI helpers (client) =======
function xmur3(str: string) {
  let h = 1779033703 ^ str.length
  for (let i=0; i<str.length; i++) {
    h = Math.imul(h ^ str.charCodeAt(i), 3432918353)
    h = (h << 13) | (h >>> 19)
  }
  return function() {
    h = Math.imul(h ^ (h >>> 16), 2246822507)
    h = Math.imul(h ^ (h >>> 13), 3266489909)
    h ^= h >>> 16
    return h >>> 0
  }
}
function mulberry32(a: number) {
  return function() {
    let t = a += 0x6D2B79F5
    t = Math.imul(t ^ (t >>> 15), t | 1)
    t ^= t + Math.imul(t ^ (t >>> 7), t | 61)
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296
  }
}

export function generateLayout(w: number, h: number, mines: number, seed: string): boolean[] {
  const total = w*h
  const layout = Array(total).fill(false) as boolean[]
  const seedInt = xmur3(seed)()
  const rnd = mulberry32(seedInt)
  // reservoir-like pick unique positions
  const indices = Array.from({length: total}, (_,i)=>i)
  for (let i=0; i<mines; i++) {
    const j = i + Math.floor(rnd() * (total - i))
    const tmp = indices[i]; indices[i] = indices[j]; indices[j] = tmp
    layout[indices[i]] = true
  }
  return layout
}

export function computeNumbers(layout: boolean[], w: number, h: number): number[] {
  const arr = new Array(w*h).fill(0)
  for (let r=0; r<h; r++) for (let c=0; c<w; c++) {
    const i = r*w + c
    if (layout[i]) { arr[i] = -1; continue }
    let cnt = 0
    for (let dr=-1; dr<=1; dr++) for (let dc=-1; dc<=1; dc++) {
      if (dr===0 && dc===0) continue
      const nr = r+dr, nc = c+dc
      if (nr>=0 && nr<h && nc>=0 && nc<w && layout[nr*w+nc]) cnt++
    }
    arr[i] = cnt
  }
  return arr
}

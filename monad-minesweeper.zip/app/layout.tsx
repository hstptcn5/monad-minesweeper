
import './globals.css'
import Providers from './providers'

export const metadata = {
  title: 'Monad Minesweeper',
  description: 'Minesweeper with Monad Games ID + onchain leaderboard'
}

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en">
      <body>
        <Providers>{children}</Providers>
      </body>
    </html>
  )
}

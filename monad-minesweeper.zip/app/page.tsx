
'use client'
import { usePrivy, CrossAppAccountWithMetadata } from '@privy-io/react-auth'
import { useEffect, useMemo, useState } from 'react'
import GameBoard from '../components/GameBoard'

type Lk = { type: string, providerApp?: { id: string }, embeddedWallets?: { address: string }[] }

export default function Page() {
  const { authenticated, user, ready, login, logout } = usePrivy()
  const [addr, setAddr] = useState<string>('')
  const [username, setUsername] = useState<string>('')
  const [message, setMessage] = useState<string>('')

  useEffect(() => {
    if (ready && authenticated && user) {
      const cross = user.linkedAccounts.find((a: any) => a.type === 'cross_app' && a.providerApp?.id === 'cmd8euall0037le0my79qpz42') as Lk | undefined
      const w = cross?.embeddedWallets?.[0]?.address
      if (w) setAddr(w)
      else setMessage('Bạn cần liên kết tài khoản Monad Games ID.')
    }
  }, [ready, authenticated, user])

  useEffect(() => {
    (async () => {
      if (!addr) return
      try {
        const r = await fetch(`/api/lookup-username?wallet=${addr}`)
        const j = await r.json()
        if (j?.hasUsername) setUsername(j.user.username)
      } catch {}
    })()
  }, [addr])

  return (
    <div className="container">
      <h1>🧨 Monad Minesweeper</h1>
      {!authenticated ? (
        <div>
          <p>Đăng nhập bằng Monad Games ID để chơi và lưu điểm onchain.</p>
          <button onClick={login}>Sign in with Monad Games ID</button>
        </div>
      ) : (
        <div>
          <div className="hud">
            <div><b>Wallet:</b> {addr.slice(0,6)}…{addr.slice(-4)}</div>
            <div><b>Username:</b> {username || <a href="https://monad-games-id-site.vercel.app/" target="_blank">Claim username</a>}</div>
            <button onClick={logout}>Logout</button>
          </div>

          <GameBoard player={addr} />
        </div>
      )}
    </div>
  )
}

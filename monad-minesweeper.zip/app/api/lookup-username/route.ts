
import { NextRequest, NextResponse } from 'next/server'

export async function GET(req: NextRequest) {
  const wallet = req.nextUrl.searchParams.get('wallet')
  if (!wallet) return NextResponse.json({ error: 'wallet required' }, { status: 400 })
  try {
    const r = await fetch(`https://monad-games-id-site.vercel.app/api/check-wallet?wallet=${wallet}`, { cache: 'no-store' })
    const j = await r.json()
    return NextResponse.json(j)
  } catch (e: any) {
    return NextResponse.json({ error: e.message }, { status: 500 })
  }
}

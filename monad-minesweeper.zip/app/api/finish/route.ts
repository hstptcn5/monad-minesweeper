
import { NextRequest, NextResponse } from 'next/server'
import { getBoard, markFinished } from '../new-board/route'
import { simulate, type Params } from '../../../lib/sim'
import { computeScore } from '../../../lib/score'
import { passesGuards } from '../../../lib/guards'
import { writeUpdatePlayerData } from '../../../lib/monad'

export async function POST(req: NextRequest) {
  try {
    const { boardId, player, moves, duration_ms } = await req.json()
    if (!boardId || !player || !moves) return NextResponse.json({ error: 'missing fields' }, { status: 400 })
    const board = getBoard(boardId)
    if (!board) return NextResponse.json({ error: 'board not found or expired' }, { status: 400 })
    if (board.player.toLowerCase() !== String(player).toLowerCase()) {
      return NextResponse.json({ error: 'player mismatch' }, { status: 400 })
    }

    const sim = simulate(board.params, board.seed, moves)
    if (!sim.valid) return NextResponse.json({ error: 'invalid moves' }, { status: 400 })

    const isWin = sim.state === 'WIN'
    const totalClicks = moves.length
    const safeOpens = sim.revealedCount || 0
    const scoreDelta = computeScore(board.params, duration_ms, totalClicks, safeOpens, isWin)

    if (!passesGuards({ duration_ms, moves, scoreDelta })) {
      return NextResponse.json({ error: 'guard_tripped' }, { status: 429 })
    }

    let tx: `0x${string}` | undefined
    if (isWin) {
      tx = await writeUpdatePlayerData(player, BigInt(scoreDelta), 1n)
    }

    // For demo, clear board after finish to avoid replay
    markFinished(boardId)

    return NextResponse.json({ ok: true, isWin, scoreDelta, tx })
  } catch (e: any) {
    return NextResponse.json({ error: e.message }, { status: 500 })
  }
}
